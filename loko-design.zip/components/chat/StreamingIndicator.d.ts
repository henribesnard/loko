export interface StreamingIndicatorProps {}
